"""
backend.py — Adarsh AI Clone v10.6
High-fidelity Indian Neural Voice (en-IN-PrabhatNeural) with zero-latency pipelined streaming,
identity loaders, conversation memory, response cleaning, Ollama diagnostics.
Imported by app.py. All logic lives here — app.py stays clean.
"""

import io
import json
import os
import re
import sys
import threading
import time
from datetime import datetime

# Windows asyncio event loop policy fix
if sys.platform == "win32":
    try:
        import asyncio
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    except Exception:
        pass

HISTORY_FILE = "chat_history.json"

# ─────────────────────────────────────────────
# MEMORY
# ─────────────────────────────────────────────

def load_history(n: int = 10) -> list:
    """Load last n chat exchanges from JSON file."""
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data[-n:] if isinstance(data, list) else []
    except (json.JSONDecodeError, IOError):
        return []


def get_initial_history(n: int = 10) -> list:
    """Load past conversations formatted for Gradio Chatbot (role-based dicts)."""
    raw = load_history(n)
    formatted = []
    for entry in raw:
        if isinstance(entry, (list, tuple)) and len(entry) >= 2:
            u, a = str(entry[0]).strip(), str(entry[1]).strip()
            if u and a and not a.lower().startswith("error connecting to ollama"):
                formatted.append({"role": "user", "content": u})
                formatted.append({"role": "assistant", "content": a})
    return formatted


def save_history(data: list) -> bool:
    """Save the full history list to JSON."""
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except IOError as e:
        print(f"[backend] Save error: {e}")
        return False


def clear_history() -> bool:
    """Wipe chat history file."""
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return True
    except IOError:
        return False


def build_messages(system_prompt: str, current_message: str, n: int = 6) -> list:
    """
    Build a properly formatted Ollama messages list for multi-turn chat.
    Injects current date/time so the AI always knows what time it is.
    """
    now = datetime.now()
    time_str = now.strftime("%A, %d %B %Y, %I:%M %p")
    time_injection = f"\n\nCurrent date and time: {time_str} IST (India Standard Time)"
    full_system = system_prompt + time_injection

    messages = [{"role": "system", "content": full_system}]

    past = load_history(n)
    for entry in past:
        if not isinstance(entry, (list, tuple)) or len(entry) < 2:
            continue
        user_msg, bot_reply = str(entry[0]).strip(), str(entry[1]).strip()
        if (
            not user_msg
            or not bot_reply
            or bot_reply.lower().startswith("ollama error")
            or bot_reply.lower().startswith("error connecting to ollama")
            or "[winerror" in bot_reply.lower()
        ):
            continue
        messages.append({"role": "user",      "content": user_msg})
        messages.append({"role": "assistant", "content": bot_reply})

    messages.append({"role": "user", "content": current_message})
    return messages


# ─────────────────────────────────────────────
# IDENTITY & KNOWLEDGE LOADERS
# ─────────────────────────────────────────────

def load_identity(identity_file: str = "identity.json") -> dict:
    """Load identity data from JSON file. Returns empty dict if not found."""
    if not os.path.exists(identity_file):
        return {}
    try:
        with open(identity_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"[backend] Identity load error: {e}")
        return {}


def load_knowledge_base(kb_file: str = "knowledge_base.json") -> str:
    """Load knowledge_base.json and return formatted string for system prompt."""
    if not os.path.exists(kb_file):
        return ""
    try:
        with open(kb_file, "r", encoding="utf-8") as f:
            kb = json.load(f)

        lines = ["\n--- ADDITIONAL KNOWLEDGE ABOUT ADARSH ---"]
        for section, entries in kb.items():
            if section == "faqs":
                lines.append("\nFrequently Asked Questions:")
                for item in entries:
                    if isinstance(item, dict):
                        lines.append(f"  Q: {item.get('q','')}")
                        lines.append(f"  A: {item.get('a','')}")
            elif isinstance(entries, list):
                lines.append(f"\n{section.upper()}:")
                for entry in entries:
                    if isinstance(entry, str):
                        lines.append(f"  - {entry}")
        lines.append("--- END KNOWLEDGE ---")
        return "\n".join(lines)
    except (json.JSONDecodeError, IOError) as e:
        print(f"[backend] Knowledge base load error: {e}")
        return ""


def load_personality_style(style_file: str = "personality_style.json") -> str:
    """Load personality_style.json and format into prompt instructions."""
    if not os.path.exists(style_file):
        return ""
    try:
        with open(style_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        lines = ["\n--- HOW ADARSH TALKS (PERSONALITY & TONE) ---"]

        do_not_say = data.get("do_not_say", [])
        if do_not_say:
            lines.append("\nNEVER say these (they sound like a generic AI bot):")
            for phrase in do_not_say:
                lines.append(f"  - Do NOT say: \"{phrase}\"")

        tone_rules = data.get("tone_rules", [])
        if tone_rules:
            lines.append("\nTONE & CONVERSATION RULES:")
            for rule in tone_rules:
                lines.append(f"  - {rule}")

        patterns = data.get("speech_patterns", {})
        if patterns:
            starters = ", ".join(f'"{s}"' for s in patterns.get("sentence_starters", []))
            agree = ", ".join(f'"{a}"' for a in patterns.get("how_to_agree", []))
            lines.append("\nNATURAL SPEECH HABITS:")
            if starters:
                lines.append(f"  - Natural starters: {starters}")
            if agree:
                lines.append(f"  - How to agree: {agree}")

        examples = data.get("example_responses", {})
        if examples:
            lines.append("\nFEW-SHOT EXAMPLES OF HOW ADARSH ANSWERS:")
            for q, a in examples.items():
                lines.append(f"  Q: \"{q}\"")
                lines.append(f"  Adarsh: {a}")

        lines.append("--- END PERSONALITY INSTRUCTIONS ---")
        return "\n".join(lines)
    except (json.JSONDecodeError, IOError) as e:
        print(f"[backend] Personality style load error: {e}")
        return ""


def build_system_prompt(identity: dict) -> str:
    """Build a smart, unrestricted system prompt from identity.json."""
    if not identity:
        return ""

    name       = identity.get("name", "Adarsh Singh")
    reg        = identity.get("registration_number", "")
    course     = identity.get("course", "")
    semester   = identity.get("semester", "")
    year       = identity.get("year", "")
    university = identity.get("university", "")
    guide      = identity.get("guide", "")
    guide_role = identity.get("guide_role", f"{guide} is your professor and supervisor.")
    project    = identity.get("project", "")
    hobbies    = ", ".join(identity.get("hobbies", []))
    skills     = ", ".join(identity.get("skills", []))

    return f"""You are {name}, a real {year} {course} student at {university}, talking with someone.

YOUR IDENTITY (never deny or forget this):
- Name: {name}
- Reg No: {reg}
- Course: {course}, {semester}, {year}
- University: {university}
- Project guide: {guide} ({guide_role})
- PBL-2 Project: {project}
- Hobbies: {hobbies}
- Skills: {skills}

HOW YOU BEHAVE — READ THIS CAREFULLY:
You are a smart, curious, real college student. You talk about ANYTHING — world events, technology, science, movies, sports, current affairs, philosophy, whatever. You are NOT a restricted bot. You have opinions. You engage. You are knowledgeable.

When asked about world events or general knowledge: answer confidently using what you know.
When asked about something that happened very recently (today's breaking news you'd have no way of knowing): say "I haven't seen that news, but let me think about it..." and engage anyway.
When asked personal questions about Adarsh: answer from your identity above.

TONE RULES (NON-NEGOTIABLE):
- Talk like a real 21-year-old student — casual, direct, natural
- Keep answers concise unless they need detail
- Use contractions: "I'm", "don't", "it's" — never "I am", "do not"
- NEVER say "Certainly!", "Absolutely!", "Great question!", "As an AI...", "I'd be happy to help!"
- NEVER refuse to engage with a topic — find a way to discuss it
- No bullet point lists in replies — write in natural flowing sentences
- No markdown formatting (no **bold**, no ## headers) — plain conversational text only"""


# ─────────────────────────────────────────────
# RESPONSE CLEANING & SENTENCE SPLITTING
# ─────────────────────────────────────────────

def clean_reply(raw: str, max_chars: int = 2500) -> str:
    """
    Clean LLM output for display:
    - Strip prefixes ('Adarsh:', 'Adarsh Singh:', 'Assistant:', 'AI:')
    - Strip surrounding quotes ('"..."' or '\'...\'')
    - Remove markdown bold/italic/headers
    - Convert bullet lists to natural sentences
    - Remove Hindi/Devanagari
    - Preserve full conversational responses without premature truncation
    """
    text = raw.strip()

    # Strip leading quotes
    text = text.lstrip('"\' ')

    # Strip conversational role prefixes
    text = re.sub(r"^(?:Adarsh(?:\s+Singh)?|Assistant|AI)\s*:\s*", "", text, flags=re.IGNORECASE).strip()

    # Strip quotes that may have followed the prefix
    text = text.lstrip('"\' ')

    # Strip trailing quotes
    text = text.rstrip('"\' ')

    # Remove markdown headers
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)

    # Remove markdown bold/italic
    text = re.sub(r"\*{1,3}(.*?)\*{1,3}", r"\1", text)

    # Convert numbered lists "1. item" -> inline text
    text = re.sub(r"^\d+\.\s+", "", text, flags=re.MULTILINE)

    # Convert bullet points "- item" or "* item" -> inline
    text = re.sub(r"^[-*•]\s+", "", text, flags=re.MULTILINE)

    # Strip Devanagari Unicode range
    text = re.sub(r"[\u0900-\u097F]+", "", text)

    # Collapse multiple newlines and spaces
    text = re.sub(r"\n{2,}", " ", text)
    text = re.sub(r"\n", " ", text)
    text = re.sub(r" {2,}", " ", text).strip()

    # Final trim of quotes
    text = text.strip('"\' ')

    # Truncate cleanly at sentence boundary only if exceeding safety limit
    if len(text) > max_chars:
        cutoff = text[:max_chars].rfind(".")
        text = text[:cutoff + 1] if cutoff > 80 else text[:max_chars].rstrip() + "..."

    return text if text else "Ask me anything."


def clean_for_tts(text: str) -> str:
    """
    Cleaning specifically for text-to-speech.
    Removes symbols, markdown, and formatting to produce clean spoken English.
    """
    t = text
    t = re.sub(r"\*{1,3}(.*?)\*{1,3}", r"\1", t)
    t = re.sub(r"^#{1,6}\s+", "", t, flags=re.MULTILINE)
    t = re.sub(r"^\d+\.\s+", "", t, flags=re.MULTILINE)
    t = re.sub(r"^[-*•]\s+", "", t, flags=re.MULTILINE)
    t = re.sub(r"[^\x00-\x7F]+", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = t.replace("...", ".")
    return t


HONORIFICS = {'dr.', 'mr.', 'mrs.', 'ms.', 'prof.', 'sr.', 'jr.', 'vs.', 'etc.', 'b.tech.', 'm.tech.', 'ph.d.'}

def split_first_chunk(text: str) -> tuple[str, str]:
    """
    Splits text into (first_chunk, remaining_chunk) for zero-latency pipelined speech.
    Respects honorifics, abbreviations, and sentence boundaries.
    """
    matches = list(re.finditer(r'([.!?])(?:\s+(?=[A-Z0-9"\'\n])|$)', text))
    for m in matches:
        end_pos = m.end()
        candidate = text[:end_pos].strip()
        last_word = candidate.split()[-1].lower() if candidate.split() else ''
        if last_word in HONORIFICS:
            continue
        if len(candidate) >= 15:
            remaining = text[end_pos:].strip()
            return candidate, remaining
    return text, ''


# ─────────────────────────────────────────────
# VOICE SUBSYSTEM — Natural Indian Neural Voice (en-IN-PrabhatNeural)
# Zero-Latency Pipelined Streaming + SAPI5 Fallback
# ─────────────────────────────────────────────

VOICE_NAME = "en-IN-PrabhatNeural"

_pygame_inited = False
_is_speaking_flag = False
_playback_generation_id = 0
_playback_lock = threading.Lock()


def _init_pygame():
    global _pygame_inited
    if not _pygame_inited:
        try:
            import pygame
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=1024)
            _pygame_inited = True
        except Exception:
            try:
                import pygame
                pygame.mixer.init()
                _pygame_inited = True
            except Exception as e:
                print(f"[backend] Pygame mixer init error: {e}")


_speaker = None
_speaker_lock = threading.Lock()


def _get_sapi_speaker():
    """Thread-safe SAPI voice instance getter for offline fallback."""
    global _speaker
    with _speaker_lock:
        if _speaker is None:
            try:
                import pythoncom
                import win32com.client
                pythoncom.CoInitialize()
                _speaker = win32com.client.Dispatch("SAPI.SpVoice")
                voices = _speaker.GetVoices()
                for i in range(voices.Count):
                    desc = voices.Item(i).GetDescription().lower()
                    if "david" in desc or "male" in desc:
                        _speaker.Voice = voices.Item(i)
                        break
                _speaker.Rate = 1
            except Exception as e:
                print(f"[backend] SAPI init error: {e}")
        return _speaker


def is_speaking() -> bool:
    """Return True if TTS audio is currently actively playing."""
    global _is_speaking_flag
    try:
        import pygame
        if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
            return True
    except Exception:
        pass

    try:
        import pythoncom
        pythoncom.CoInitialize()
        spk = _get_sapi_speaker()
        if spk and spk.Status.RunningState == 2:
            return True
    except Exception:
        pass

    return _is_speaking_flag


def stop_speaking() -> None:
    """Stop any currently playing speech immediately."""
    global _is_speaking_flag, _playback_generation_id
    with _playback_lock:
        _playback_generation_id += 1
        _is_speaking_flag = False

    try:
        import pygame
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
            if hasattr(pygame.mixer.music, "unload"):
                pygame.mixer.music.unload()
    except Exception:
        pass

    try:
        import pythoncom
        pythoncom.CoInitialize()
        spk = _get_sapi_speaker()
        if spk:
            spk.Speak("", 2)  # SVSFPurgeBeforeSpeak
    except Exception:
        pass


def fetch_tts_audio_sync(text: str) -> io.BytesIO:
    """
    Synthesize text to an in-memory MP3 BytesIO using en-IN-PrabhatNeural.
    Returns BytesIO with valid audio bytes, or None on failure.
    """
    safe_text = clean_for_tts(text)
    if not safe_text:
        return None
    try:
        import asyncio
        import edge_tts

        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

        async def _synth():
            comm = edge_tts.Communicate(safe_text, VOICE_NAME)
            buf = io.BytesIO()
            async for chunk in comm.stream():
                if chunk["type"] == "audio":
                    buf.write(chunk["data"])
            buf.seek(0)
            return buf

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            buf = loop.run_until_complete(_synth())
            if buf and len(buf.getvalue()) > 0:
                return buf
        finally:
            loop.close()
    except Exception as e:
        print(f"[backend] Edge-TTS fetch note: {e}")
    return None


def speak_pipelined_async(c1_buf: io.BytesIO, rem_text: str = "") -> None:
    """
    Pipelined zero-latency playback:
    1. Immediately begins playing chunk 1 (<1ms latency).
    2. Downloads chunk 2 audio in background while chunk 1 is playing.
    3. Seamlessly chains chunk 2 without dropping is_speaking flag.
    4. Guarantees 100% of words are spoken without cut-offs.
    """
    global _is_speaking_flag, _playback_generation_id
    stop_speaking()
    _init_pygame()

    with _playback_lock:
        _playback_generation_id += 1
        my_gen = _playback_generation_id
        _is_speaking_flag = True

    try:
        import pygame
        pygame.mixer.music.load(c1_buf)
        pygame.mixer.music.play()
    except Exception as e:
        print(f"[backend] Pipelined c1 load error: {e}")
        speak_async(rem_text)
        return

    def _worker():
        global _is_speaking_flag
        import pygame

        # 1. Fetch remaining text while chunk 1 is playing
        rem_buf = None
        safe_rem = clean_for_tts(rem_text)
        if safe_rem:
            rem_buf = fetch_tts_audio_sync(safe_rem)

        # 2. Wait for chunk 1 to finish
        while pygame.mixer.music.get_busy():
            with _playback_lock:
                if my_gen != _playback_generation_id:
                    return
            time.sleep(0.01)

        with _playback_lock:
            if my_gen != _playback_generation_id:
                return

        # 3. If there is remaining audio, play chunk 2 seamlessly
        if rem_buf and len(rem_buf.getvalue()) > 0:
            try:
                if hasattr(pygame.mixer.music, "unload"):
                    pygame.mixer.music.unload()
                pygame.mixer.music.load(rem_buf)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    with _playback_lock:
                        if my_gen != _playback_generation_id:
                            return
                    time.sleep(0.01)
            except Exception as e:
                print(f"[backend] Playback chunk 2 error: {e}")

        # Finished all audio playback
        with _playback_lock:
            if my_gen == _playback_generation_id:
                _is_speaking_flag = False

    threading.Thread(target=_worker, daemon=True).start()


def speak_async(text: str) -> None:
    """
    Standard async speech playback.
    Synthesizes full text via en-IN-PrabhatNeural with automatic SAPI5 offline fallback.
    """
    global _is_speaking_flag, _playback_generation_id
    safe_text = clean_for_tts(text)
    if not safe_text:
        return

    stop_speaking()

    with _playback_lock:
        _playback_generation_id += 1
        my_gen = _playback_generation_id

    def _worker():
        global _is_speaking_flag
        _init_pygame()

        # 1. Primary: High-fidelity Edge-TTS Indian Neural Voice
        buf = fetch_tts_audio_sync(safe_text)
        with _playback_lock:
            if my_gen != _playback_generation_id:
                return

        if buf and len(buf.getvalue()) > 0:
            try:
                import pygame
                with _playback_lock:
                    _is_speaking_flag = True
                if hasattr(pygame.mixer.music, "unload"):
                    pygame.mixer.music.unload()
                pygame.mixer.music.load(buf)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    with _playback_lock:
                        if my_gen != _playback_generation_id:
                            return
                    time.sleep(0.02)
                return
            except Exception as e:
                print(f"[backend] Pygame playback error: {e}")
            finally:
                with _playback_lock:
                    if my_gen == _playback_generation_id:
                        _is_speaking_flag = False

        # 2. Offline Fallback: Local Windows SAPI voice
        try:
            import pythoncom
            pythoncom.CoInitialize()
            spk = _get_sapi_speaker()
            if spk:
                with _playback_lock:
                    _is_speaking_flag = True
                spk.Speak(safe_text, 1)  # SVSFlagsAsync
                while spk.Status.RunningState == 2:
                    with _playback_lock:
                        if my_gen != _playback_generation_id:
                            spk.Speak("", 2)
                            return
                    time.sleep(0.04)
        except Exception as e:
            print(f"[backend] SAPI fallback error: {e}")
        finally:
            with _playback_lock:
                if my_gen == _playback_generation_id:
                    _is_speaking_flag = False

    threading.Thread(target=_worker, daemon=True).start()


# ─────────────────────────────────────────────
# DIAGNOSTICS
# ─────────────────────────────────────────────

def check_ollama(model: str = "llama3.2:3b") -> dict:
    """Check if Ollama is running and the model is available."""
    try:
        import ollama
        models = ollama.list()
        model_list = models.get("models", []) if isinstance(models, dict) else getattr(models, "models", [])
        available = []
        for m in model_list:
            if isinstance(m, dict):
                name = m.get("name", m.get("model", ""))
            else:
                name = getattr(m, "model", getattr(m, "name", ""))
            if name:
                available.append(name)

        base_model = model.split(":")[0]
        matched = any(model in a or (base_model in a and "3b" in a) for a in available)

        if matched or model in available:
            return {"ok": True, "message": f"Ollama running | Model '{model}' ready"}
        else:
            return {
                "ok": False,
                "message": (
                    f"Ollama running but model '{model}' not found.\n"
                    f"Available: {available}\n"
                    f"Fix: ollama pull {model}"
                ),
            }
    except Exception as e:
        return {
            "ok": False,
            "message": (
                f"Ollama not reachable: {e}\n"
                "Fix: run `ollama serve` in a terminal."
            ),
        }


def history_stats() -> dict:
    """Return basic stats about stored chat history."""
    hist = load_history(1000)
    total = len(hist)
    empty = sum(
        1 for entry in hist
        if isinstance(entry, (list, tuple)) and len(entry) >= 2 and not (entry[1] or "").strip()
    )
    return {
        "total_exchanges": total,
        "empty_replies": empty,
        "file": HISTORY_FILE,
        "exists": os.path.exists(HISTORY_FILE),
    }


if __name__ == "__main__":
    print("=== backend.py self-test ===")
    print("Testing clean_reply:", clean_reply("Adarsh: Hello there!"))
    print("Testing history stats:", history_stats())
    print("Testing Ollama:", check_ollama()["message"])
